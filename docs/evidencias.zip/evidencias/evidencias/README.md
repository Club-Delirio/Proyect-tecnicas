# Evidencias de las sesiones de trabajo

Capturas tomadas por los integrantes durante el desarrollo de las prácticas de campo de las semanas 1 a 6.

Curso: Técnicas de Programación Orientada a Objetos (SIST1202A) — UPN Cajamarca, 2026-2
Repositorio: `Club-Delirio/Proyect-tecnicas`

---

## Índice

| Archivo | Qué documenta | Semana del sílabo |
|---|---|---|
| `01-inicializacion-repositorio.png` | Inicialización del repositorio local, primer commit y renombrado de la rama `master` a `main`. | 1–2 |
| `02-configuracion-remoto-origin.png` | Configuración del repositorio remoto con `git remote set-url` y verificación con `git remote -v`. | 1–2 |
| `03-creacion-rama-y-push-objetivos.png` | Creación de la rama `docs/objetivos-base`, commit del archivo de objetivos y publicación con `git push -u`. | 3–4 |
| `04-sincronizacion-equipo-jhann.jpg` | Sincronización del repositorio en la máquina de Jhann. Se observa el `git pull` trayendo los archivos del equipo. | 3–4 |
| `05-sincronizacion-equipo-sumil.jpg` | Sincronización y creación de rama de trabajo en la máquina de Sumil. Se observa el `fast-forward` con los archivos incorporados. | 3–4 |
| `06-conflicto-detectado-en-pull-request.jpg` | Pull request bloqueado por conflicto: *"This branch has conflicts that must be resolved"*. | 3–4 |
| `07-resolucion-de-conflicto-marcadores.png` | Editor de conflictos mostrando los marcadores `<<<<<<<`, `=======` y `>>>>>>>` en `docs/objetivos.md`, antes de resolverlos. | 3–4 |
| `08-pull-requests-abiertos.png` | Lista de pull requests del repositorio, con los abiertos y los ya cerrados. | 3–4 |
| `09-ramas-y-archivos-en-main.png` | Ramas remotas del proyecto y archivos presentes en la rama `main`. | 1–6 |
| `10-contenido-de-docs-y-objetivos.png` | Contenido de la carpeta `docs/` y del archivo de objetivos ya redactado. | 6 |
| `11-historial-de-commits-por-autor.png` | Conteo de commits fusionados en `main` por cada integrante. Sustenta el porcentaje de participación de la carátula del informe. | 1–6 |

---

## Evidencia pendiente

| Archivo | Qué debe mostrar | Cuándo capturarlo |
|---|---|---|
| `12-compilacion-y-ejecucion.png` | La salida de `javac -encoding UTF-8 -d build $(find src -name "*.java")` sin errores, seguida del menú del programa en ejecución. | Cuando las tres clases del paquete `semana5` estén fusionadas en `main` |

---

## Cómo reproducir la última evidencia

```
git checkout main
git pull origin main
javac -encoding UTF-8 -d build $(find src -name "*.java")
java -cp build semana5.Semana5
```

El `javac` no debe devolver ningún mensaje. El `java` debe abrir el menú de ocho opciones descrito en `docs/manual-usuario.md`.
